# Mock readme file

This is a mock readme file for testing purposes.

```
$ ghet download -p pkg/ghet/download/testdata/README.md
$ cat README.md
# Mock readme file
```
